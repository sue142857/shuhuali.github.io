This fold contains all input binary images for reversible shape transforms, where
"selected_pairs"
         are 35 pairs of images selected and shown in the paper; 
"created_binaries" 
        are images created by ourselves;
"MPEG7_plus_NONRIGID"
        are images from two public datasets 
      " http://www.dabi.temple.edu/~shape/MPEG7/dataset.html " and
      " https://sites.google.com/site/xiangbai/animaldataset ".

For details, please refer to
      Li, Shuhua and Mahdavi-Amiri, Ali and Hu, Ruizhen and Liu, Han and Zou, Changqing and Van Kaick, Oliver and Liu, Xiuping and Huang, Hui and Zhang, Hao, Construction and fabrication of reversible shape transforms[J]. ACM Trans. Graph., 2018, 37(6): 190:1-190:14.